<?php
ini_set("display_errors","on");
error_reporting(E_ERROR);
if(isset($_POST['submitted']))
{
$conn=mysql_connect("localhost","root","") or die("could not connect to database")."<br>";
$select_db=mysql_select_db('mydb') or die("could not find database")."<br>";
$city=$_POST['fname'];
$gender=$_POST['gen'];
$service=$_POST['ser'];
if($city=="1")
{
$city="mumbai";

$sqlinsert="INSERT INTO custoinfo(city) VALUES ('$city');";
mysql_query($sqlinsert) or die("error inserting in new record!!");

}
elseif($city=="2")
{
$city="delhi";

$sqlinsert="INSERT INTO custoinfo(city) VALUES ('$city');";
mysql_query($sqlinsert) or die("error inserting in new record!!");	
}
elseif($city=="3")
{
$city="kolkata";

$sqlinsert="INSERT INTO custoinfo(city) VALUES ('$city');";
mysql_query($sqlinsert) or die("error inserting in new record!!");	
}
else{echo "pls enter again";}
	
}
if(isset($_POST['submitted1']))
{
$conn=mysql_connect("localhost","root","") or die("could not connect to database")."<br>";
$select_db=mysql_select_db('mydb') or die("could not find database")."<br>";
$city=$_POST['fname'];
$gender=$_POST['gen'];
$service=$_POST['ser'];
if($gender=="1")
{
$gender="female";

$sqlinsert="INSERT INTO custoinfo(gender) VALUES ('$gender');";
mysql_query($sqlinsert) or die("error inserting in new record!!");

}
elseif($gender=="2")
{
$gender="male";

$sqlinsert="INSERT INTO custoinfo(gender) VALUES ('$gender');";
mysql_query($sqlinsert) or die("error inserting in new record!!");	
}



else{echo "pls enter again";}
	
}

if(isset($_POST['submitted2']))
{
$conn=mysql_connect("localhost","root","") or die("could not connect to database")."<br>";
$select_db=mysql_select_db('mydb') or die("could not find database")."<br>";

$service=$_POST['ser'];
if($service=="1")
{
$service="inquiry";

$sqlinsert="INSERT INTO custoinfo(service) VALUES ('$service');";
mysql_query($sqlinsert) or die("error inserting in new record!!");

}
elseif($service=="2")
{
$service="complaint";

$sqlinsert="INSERT INTO custoinfo(service) VALUES ('$service');";
mysql_query($sqlinsert) or die("error inserting in new record!!");	
}



else{echo "pls enter again";}
	
}





	
?>
<?php 
echo $newrecord;
?>