<html>
<head>
<title>about</title>
<link rel="stylesheet" type="text/css" href="cc.css">
</head>
<body>
<div class="d1">
<div id=hd>Online Assignment Submission System
</div>
</div>
<form method="post" action="1t.php">
<input type="hidden" name="submitted" value="true">
<table>
<tr>
<td>Enter student id:<INPUT TYPE="TEXT" NAME="id"></td>
</tr>
<tr>
<td>Enter Marks:<INPUT TYPE="TEXT" NAME="mpm"><td>
</tr>
<tr>
<input type="submit" value="ADD MARKS">
</tr>
</table>
</form>
</body>
</html>
<?php
include('dbcon.php');
include('insertm.php');
?>
