<?php 
include('header.php');
?>
 
<body>
<br>
<br>
<div class="container">
	<div class="alert alert-success">Sum the Numbers in a Column</div>
	<br />
	<table  class="table table-striped table-bordered">
		<thead>
			<tr>
				<th>ID</th>
				<th> Name</th>
				<th>SOOAD</th>
				<th>MP</th>
				<th>CN</th>
				<th>OS</th>
				<th>WT</th>
			</tr>
		</thead>
		<tbody>
			<?php 
				$query=mysql_query("select * from student")or die(mysql_error());
				while($row=mysql_fetch_array($query)){
				$id=$row['id'];
			?>
			<tr>
				<td><?php echo $row['id'] ?></td>
				<td><?php echo $row['name'] ?></td>
				<td><?php echo $row['sooad'] ?></td>
				<td><?php echo $row['mp'] ?></td>
				<td><?php echo $row['cn'] ?></td>
				<td><?php echo $row['os'] ?></td>
				<td><?php echo $row['wt'] ?></td>
			</tr>
			<?php } ?>
		</tbody>
	</table>
	<?php
		$result = mysql_query("SELECT sum(amount) FROM student") or die(mysql_error());
		while ($rows = mysql_fetch_array($result)) {
	?>
	<div class="pull-right">
		<div class="span">
			<div class="alert alert-success"><i class="icon-credit-card icon-large"></i>&nbsp;Total:&nbsp;<?php echo $rows['sum(amount)']; ?></div>
		</div>
	</div>
	<?php }
 
	$result1 = mysql_query("SELECT sum(qty) FROM product") or die(mysql_error());
	while ($rows1 = mysql_fetch_array($result1)) {
	?>	
	<div class="pull-right">
		<div class="span">
			<div class="alert alert-info"><i class="icon-credit-card icon-large"></i>&nbsp;Total number of Items:&nbsp;<?php echo $rows1['sum(qty)']; ?></div>
		</div>
	</div>
	<?php } ?>
</div>
</body>
</html>