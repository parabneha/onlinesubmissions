<?php
include('session.php');
?>

<html>
<head>
<title>1</title>
<head>
<link rel="stylesheet" href="css1.css" type="text/css">
</head>
<body>

<br><br><br>
<div id="container">

<div class="d2">
</div>
<div class="d3">
<ul>
<li><a href="1.php" class="p1">MP</a></li>
<li><a href="2.php" class="p2">CN</a></li>
<li><a href="3.php">SOOAD</a></li>
<li><a href="4.php">BCE</a></li>
<li><a href="5.php">OS</a></li>
<li><a href="6.php">WT</a></li>
</div><br>
<div class="d2">
</div>

<div class="g1">
     <a href="quecn.html"><img  src="assignment.jpg" alt="Fjords" width="200" height="200"></a>
	 <div class="m1">
	 <div class="text">ASSIGNMENT QUESTIONS <br>AVAILABLE HERE...</div>
	 </div>
</div>

<div class="g2">
     <a href="file.php"><img src="a1.png" alt="Forest" width="200" height="170"></a>
</div>

<div class="g2">
     <a href="notes.html"><img src="notes.png" alt="Northern Lights" width="200" height="170"></a>
	 <div class="m4">
	 <div class="text">By Prof. Kapase</div>
	 </div>
</div>
<footer>Copyright &copy; OAS.com</footer>
</body>
</html>