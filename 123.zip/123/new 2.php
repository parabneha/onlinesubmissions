<HTML>
<HEAD>
<TITLE>FORM</TITLE>

</HEAD>
<BODY>
<FORM name="f1" method="post" >
<input type="hidden" name="submitted" value="true">

Enter 1.Mumbai 2.Delhi 3.Kolkata
<LABEL>city :</LABEL>
<INPUT TYPE="INT" NAME="fname">
<CENTER><INPUT TYPE="SUBMIT" VALUE="SUBMIT"> </CENTER></form>
<br>
<br>
<br>

<FORM name="f2" method="post" >
<input type="hidden" name="submitted1" value="true">

Enter 1.female 2.Male
<LABEL>gender:</LABEL>
<INPUT TYPE="INT" NAME="gen">
<CENTER><INPUT TYPE="SUBMIT" VALUE="SUBMIT"> </CENTER></FORM>
<br>
<br>
<br>
<FORM name="f3" method="post" >
<input type="hidden" name="submitted2" value="true">

Enter 1.Inquiry 2.Complaint
<LABEL>Service:</LABEL>
<INPUT TYPE="INT" NAME="ser">


<CENTER><INPUT TYPE="SUBMIT" VALUE="SUBMIT"> </CENTER></FORM>



</BODY>
</HTML>
<?php
include('dbcon.php');
include('new 1.php');
?>