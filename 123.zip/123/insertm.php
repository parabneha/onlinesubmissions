<?php
ini_set("display_errors","on");
error_reporting(E_ERROR);


if(isset($_POST['submitted']))
{
$conn=mysql_connect("localhost","root","") or die("could not connect to database")."<br>";
$select_db=mysql_select_db('online') or die("could not find database")."<br>";
$id=$_POST['id'];
$mp=$_POST['mpm'];
//$sql = "UPDATE studentnew SET mp='$mp' WHERE id=$id";

$sql="INSERT INTO studentnew('id','mp') VALUES ('$id','$mp');";
mysql_query($sql) or die("error inserting in new record!!");
}
?>
<?php 
echo $newrecord;
?>