<!DOCTYPE html>
<html>
<head>
<title>Login Form</title>
<link href="style3.css" rel="stylesheet" type="text/css">
</head>

<body>

<div class="d1">
<div id=hd>Check Your Result Here...
</div>
</div>
<table width="1000" border="1">
<tr>
<th>Id</th>
<th>SOOAD</th>
<th>MP</th>
<th>CN</th>
<th>OS</th>
<th>WT</th>

<tr>

<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "online";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT * FROM studentnew";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($assignment = $result->fetch_assoc()) 
{
        echo "<tr>";
	echo "<td>".$assignment['id']."</td>";
	echo "<td>".$assignment['sooad']."</td>";
	echo "<td>".$assignment['mp']."</td>";
	echo "<td>".$assignment['cn']."</td>";
	echo "<td>".$assignment['os']."</td>";
	echo "<td>".$assignment['wt']."</td>";
	echo "</tr>";

    }
} else {
    echo "0 results";
}

$conn->close();
?> 
</table>
</body>
</html>
