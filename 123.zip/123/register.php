<?php
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$link = mysqli_connect("localhost", "root", "", "se");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
 
// Escape user inputs for security
$firstname = mysqli_real_escape_string($link, $_REQUEST['first_name']);
$lastname = mysqli_real_escape_string($link, $_REQUEST['last_name']);
$emailaddress = mysqli_real_escape_string($link, $_REQUEST['email']);
$gender = mysqli_real_escape_string($link, $_REQUEST['gender']);
$age = mysqli_real_escape_string($link, $_REQUEST['age']);
$address = mysqli_real_escape_string($link, $_REQUEST['address']);
$password = mysqli_real_escape_string($link, $_REQUEST['password']);



// attempt insert query execution
$sql = "INSERT INTO patient (first_name, last_name,email,gender,age,address,password) VALUES ('$firstname', '$lastname', '$emailaddress','$gender','$age','$address','$password')";
if(mysqli_query($link, $sql)){
    echo "Records added successfully.";
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
 
// close connection
mysqli_close($link);
?>




