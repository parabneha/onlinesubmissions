<?php
include('session.php');
?>

<html>
<head>
<title>1</title>
<head>
<link rel="stylesheet" href="css1.css" type="text/css">
</head>
<body>
<div id="profile">
<b id="welcome">Welcome : <i><?php echo $login_session; ?></i></b>
<b id="logout"><a href="logout.php">Log Out</a></b>
</div>
<br><br><br>
<div id="container">

<div class="d2">
</div>
<div class="d3">
<ul>
<li><a href="1.php" class="p1">MP</a></li>
<li><a href="2.php">CN</a></li>
<li><a href="3.php">SOOAD</a></li>
<li><a href="4.php">BCE</a></li>
<li><a href="5.php">OS</a></li>
<li><a href="6.php">WT</a></li>
</div><br>
<div class="d2">
</div>



<div class="g2">
     <a href="file.php"><img src="a1.png" alt="Forest" width="200" height="170"></a>
</div>



<footer>Copyright &copy; OAS.com</footer>
</body>
</html>