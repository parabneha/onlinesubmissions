<?php
include('session.php');
?>
<!DOCTYPE html>
<html>
<head>
<title>Your Home Page</title>
<link href="style2.css" rel="stylesheet" type="text/css">
</head>
<body>
<div id="profile">
<b id="welcome">Welcome : <i><?php echo $login_session; ?></i></b>
<b id="logout"><a href="logout.php">Log Out</a></b>
</div>
<div id="container">
<div class="d1">
</div>
<div class="d2">
</div>
<div class="d3">
<ul>
<li><a href="1.html" class="p1">MP</a></li>
<li><a href="2.html">CN</a></li>
<li><a href="3.html">SOOAD</a></li>
<li><a href="4.html">BCE</a></li>
<li><a href="5.html">OS</a></li>
<li><a href="6.html">WT</a></li>
</ul></div><br>
<div class="d2">
</div>

<div class="g1">
     <a href="que.html"><img  src="assignment.jpg" alt="Fjords" width="200" height="200"></a>
	 <div class="m1">
	 <div class="text">ASSIGNMENT QUESTIONS <br>AVAILABLE HERE...</div>
	 </div>
</div>

<div class="g2">
     <a href="file.php"><img src="a1.png" alt="Forest" width="200" height="170"></a>
</div>

<div class="g2">
     <a href="notes.html"><img src="notes.png" alt="Northern Lights" width="200" height="170"></a>
	 <div class="m4">
	 <div class="text">By Prof. Kapase</div>
	 </div>
</div>
</div>
<footer>Copyright &copy; OAS.com</footer>
</body>
</html>
