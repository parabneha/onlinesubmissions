<?php
ini_set("display_errors","on");
error_reporting(E_ERROR);


if(isset($_POST['submitted']))
{
$conn=mysql_connect("localhost","root","") or die("could not connect to database")."<br>";
$select_db=mysql_select_db('mydb') or die("could not find database")."<br>";
$city=$_POST['fname'];
$gender=$_POST['gen'];
$sqlinsert="INSERT INTO custoinfo(city,gender,service) VALUES ('$city','$gender','$service');";
mysql_query($sqlinsert) or die("error inserting in new record!!");
}
?>
<?php 
echo $newrecord;
?>