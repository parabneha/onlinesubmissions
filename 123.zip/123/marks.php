<?Php

require "dbcon.php"; // Database connection

$count="SELECT id,name, sooad, cn, mp, sum(sooad + cn + mp ) as total from student3 group by id";

echo "<table>";
echo "<tr><th>id</th><th>name</th><th>social</th><th>math</th><th>science</th><th>total</th></tr>";

foreach ($dbo->query($count) as $row) {
echo "<tr ><td>$row[id]</td><td>$row[name]</td><td>$row[sooad]</td><td>$row[cn]</td><td>$row[mp]</td><td>$row[total]</td></tr>";
}
echo "</table>";
?>