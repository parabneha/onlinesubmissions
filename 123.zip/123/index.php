<?php
include('login.php'); // Includes Login Script

if(isset($_SESSION['login_user'])){
header("location: 1.php");
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Login Form</title>
<link href="style2.css" rel="stylesheet" type="text/css">
</head>
<body class="d1">
<div id="main">

<div id="login">
 
<h1 align="center">LOGIN</h1>     
<form action="" method="post">

<label>UserName :</label><br>
<input id="name" name="username" type="text"><br>
<label>Password :</label>
<input id="password" name="password"  type="password"><br><br>
<input name="submit" type="submit" value=" Login ">
 <span><br>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<?php echo $error; ?></span>
<h4>Don't have an account?<b id="b1"><a href="reg.php"> Register now!</a></b></h4>



</form>
</div>
</div>
</body>
</html>

