<html>
<head>
<title>Upload file</title>
<LINK REL="STYLESHEET" TYPE="TEXT/CSS" HREF="filestyle.css"> 
</head>
<body>

<center><h1><i>MCT'S <br>RAJIV GANDHI INSTITUTE OF TECHNOLOGY.</i></h1></center>
<center><h2><i><u>UPLOAD YOUR FILE</u></i><h2></center>
<br><br><br><br><center><form action="upload.php" method="post" enctype="multipart/form-data">
<input type="file" name="file">
<br>
<input type="Submit" name="Upload">
</form></center>

</body>
</html>