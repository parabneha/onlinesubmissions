<html>
<head>
<title>Login Form</title>
<link href="style1.css" rel="stylesheet" type="text/css">
</head>

<body>

<table width="1000" border="1">
<tr>
<th>Id</th>
<th>Name</th>
<th>SOOAD</th>
<th>CN</th>
<th>MP</th>
<th>TOTAL</th>
<tr>

<?Php

include('dbcon.php');

//$count="SELECT sum(sooad+cn+mp+os+wt ) as total from student;";
global $mysqli;
$res=$mysqli->query("SELECT *, sum(sooad,cn,mp ) as total from student;");
//foreach($assignment->query($count) as $row) 
{
 echo "<tr>";
	echo "<td>".$assignment['id']."</td>";
	echo "<td>".$assignment['name']."</td>";
	echo "<td>".$assignment['sooad']."</td>";
	echo "<td>".$assignment['cn']."</td>";
	echo "<td>".$assignment['mp']."</td>";
	echo "<td>".$assignment['total']."</td>";
	echo "</tr>";


}

?>
</table>
</body>
</html>