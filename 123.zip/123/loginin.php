<?php

$conn = mysqli_connect('localhost','root','','myapp');
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
$firstname=$_POST['uname'];
$passwordch=$_POST['psw'];

$sql ="Select * FROM register where email='$firstname' and password='$passwordch'";

$result=mysqli_query($conn,$sql);


$count=mysqli_num_rows($result);

if ($count==1) {
    header('location:1.html');
} else {
	
   die('Email-id or Password incorrect');
}
ob_end_flush();
?>