<?php
$conn=mysql_connect("localhost","root","") or die("could not connect to database")."<br>";
?>