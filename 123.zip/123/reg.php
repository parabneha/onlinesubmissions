<HTML>
<HEAD>
<TITLE>IVR</TITLE>

</HEAD>
<BODY>
<FORM name="f1" method="post" >
<input type="hidden" name="submitted" value="true">

Enter 1.Mumbai 2.Delhi 3.Kolkata
<LABEL>city :</LABEL>
<INPUT TYPE="INT" NAME="fname">
<br>
<br>
<br>
Enter 1.female 2.Male
<LABEL>gender:</LABEL>
<INPUT TYPE="INT" NAME="gen">
<br>
<br>
<br>
Enter 1.Inquiry 2.Complaint
<LABEL>Service:</LABEL>
<INPUT TYPE="INT" NAME="ser">


<CENTER><INPUT TYPE="SUBMIT" VALUE="SUBMIT"> </CENTER>
</FORM>


</BODY>
</HTML>
<?php
include('dbcon.php');
include('insert.php');
?>