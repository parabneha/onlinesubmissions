<?php
include('session.php');
?>

<html>
<head>
<title>1</title>
<head>
<link rel="stylesheet" href="cssn.css" type="text/css">
</head>
<body>
<div id="profile">
<b id="welcome">Welcome : <i><?php echo $login_session; ?></i></b>
<b id="logout"><a href="logout.php">Log Out</a></b>
</div>
<br><br><br>
<div id="container">

<div class="d2">
</div>
<div class="d3">
<ul>
<li><a href="1t.php" class="p1">MP</a></li>
<li><a href="2t.php">CN</a></li>
<li><a href="3t.php">SOOAD</a></li>
<li><a href="4t.php">BCE</a></li>
<li><a href="5t.php">OS</a></li>
<li><a href="6t.php">WT</a></li>
</div><br>
<div class="d2">
</div>

<div class="g1">
     <a href="quemp.html"><img  src="assignment.jpg" alt="Fjords" width="200" height="200"></a>
	 <div class="m1">
	 <div class="text">ASSIGNMENT QUESTIONS <br>AVAILABLE HERE...</div>
	 </div>
</div>

<div class="g2">
     <a href="file.php"><img src="a1.png" alt="Forest" width="200" height="170"></a>
</div>

<div class="g2">
     <a href="notes.html"><img src="notes.png" alt="Northern Lights" width="200" height="170"></a>
	 <div class="m4">
	 <div class="text">By Prof. Kapase</div>
	 </div>
	 
 <div class="g2">
     <a href="marksinsert.php"><img src="a1.png" alt="Forest" width="200" height="170"></a>
</div>

</div>

<footer>Copyright &copy; OAS.com</footer>
</body>
</html>